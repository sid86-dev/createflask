## flask-createapp

![PyPI - Python Version](https://img.shields.io/pypi/pyversions/flask-createapp)

 
## `pip install flask-createapp`
 

<br>

> ### Create your flask development environment with 2 simple commands.

<br>

### setup

```python
from createapp import Create

app = Create('app')

app.sow(server=False)

```

<br>

https://pypi.org/project/flask-createapp/

