## flask-createapp

![PyPI - Python Version](https://img.shields.io/pypi/pyversions/createflask)

 
## `pip install flask-createapp`
 

<br>

> ### Create your flask development environment with 2 simple commands.

<br>

### setup

```python
from createflask import createapp

app = createapp.Create('app')

app.sow(server=True)

```

<br>


